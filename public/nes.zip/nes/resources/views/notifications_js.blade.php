<script type="text/javascript">
    $('#checkbox-outline-messages').click(function () {
        $.get( "/mark-all-messages-as-read", function( data ) {
            $('#notification-messages-ul').html('');
        })
    });

    $('#checkbox-outline-notifs').click(function () {
        $.get( "/mark-all-likes-as-read", function( data ) {
            $('#notifications-ul').html('');
        })
    });
    
</script>