<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Favicon -->
    <link href="/frontend/assets/images/favicon.png" rel="icon" type="image/png">

    <!-- Basic Page Needs
        ================================================== -->
    <title>Profile</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Socialite is - Professional A unique and beautiful collection of UI elements">

    <!-- icons
    ================================================== -->
    <link rel="stylesheet" href="/frontend/assets/css/icons.css">

    <!-- CSS 
    ================================================== --> 
    <link rel="stylesheet" href="/frontend/assets/css/uikit.css">
    <link rel="stylesheet" href="/frontend/assets/css/style.css">
    <link rel="stylesheet" href="/frontend/assets/css/tailwind.css">  
    <link rel="stylesheet" href="/frontend/assets/css/custom.css">

    <?php echo $__env->make('pusher', array('onMessageReceived' => true, 'onMessageReceivedAlert' => false), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head> 
<body>
   

    <div id="wrapper">

        <!-- Header -->
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Main Contents -->
        <div class="main_content">
            <div class="mcontainer">

                <?php echo $__env->make('error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!--  breadcrumb -->
                


                <!-- create page-->
                
                <div class="max-w-2xl m-auto shadow-md rounded-md bg-white">  
 
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="p-7 space-y-5">
                        <div>
                            <img id="photo_preview" <?php if($u->image == ""): ?> src="person-icon.png" <?php else: ?> src="/profile_images/<?php echo e($u->image); ?>" <?php endif; ?> class="img-fluid img-thumbnail rounded mx-auto d-block" alt="profile photo" style="border-radius: 50%; width: 50%;" />
                            <input id="image" type="file" name="image" style="display: none" />
                        </div>    
                    </div>

                    <!-- form header -->
                    <div class="text-center border-b py-4">
                        <h3 class="font-bold text-lg"> <?php echo e($u->name); ?> </h3>
                    </div>
                    
                    <div class="mt-4 move-right">
                        <span>Nombre: </span>
                        <span><?php echo e($u->name); ?></span>
                    </div>

                    <div class="mt-4 move-right">
                        <span>Genero: </span>
                        <span><?php if($u->gender == 'man'): ?> Hombre <?php else: ?> Mujer <?php endif; ?></span>
                    </div>

                    <div class="mt-4 move-right">
                        <span>Pa&iacute;s: </span>
                        <span><?php echo e($u->country); ?></span>
                    </div>

                    <?php if($u->city != ""): ?>
                    <div class="mt-4 move-right">
                        <span>Ciudad: </span>
                        <span><?php echo e($u->city); ?></span>
                    </div>
                    <?php endif; ?>

                    <div class="mt-4 move-right">
                        <span>Cumplea&ntilde;os: </span>
                        <span><?php echo e(\Carbon\Carbon::parse($u->birthday)->format('j F, Y')); ?></span>
                    </div>

                    <div class="mt-4" style="padding-top: 20px; padding-bottom: 20px; width: 30%; margin: auto;">
                        <a href="/messages/<?php echo e($u->id); ?>">
                            <button type="button" style="-webkit-tap-highlight-color: rgba(0,0,0,0);
    -webkit-text-size-adjust: 100%;
    box-sizing: inherit;
    font: inherit;
    margin: 0;
    overflow: visible;
    text-transform: none;
    display: inline-block;
    margin-bottom: 0;
    font-weight: 400;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    touch-action: manipulation;
    cursor: pointer;
    background-image: none;
    border: 1px solid transparent;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    border-radius: 4px;
    user-select: none;
    color: #fff;
    background-color: #f0ad4e;
    border-color: #eea236;
    -webkit-appearance: button;">Enviar mensaje</button></a>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                </div>

        
            </div>
        </div>
        
    </div>

    <!-- open chat box -->
    <?php echo $__env->make('aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <!-- For Night mode -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script>
        (function (window, document, undefined) {
            'use strict';
            if (!('localStorage' in window)) return;
            var nightMode = localStorage.getItem('gmtNightMode');
            if (nightMode) {
                document.documentElement.className += ' night-mode';
            }
        })(window, document);
    
        (function (window, document, undefined) {
    
            'use strict';
    
            // Feature test
            if (!('localStorage' in window)) return;
    
            // Get our newly insert toggle
            var nightMode = document.querySelector('#night-mode');
            if (!nightMode) return;
    
            // When clicked, toggle night mode on or off
            nightMode.addEventListener('click', function (event) {
                event.preventDefault();
                document.documentElement.classList.toggle('dark');
                if (document.documentElement.classList.contains('dark')) {
                    localStorage.setItem('gmtNightMode', true);
                    return;
                }
                localStorage.removeItem('gmtNightMode');
            }, false);
    
        })(window, document);
    </script>
  
    <!-- Javascript
    ================================================== -->
    <script src="/frontend/assets/js/jquery-3.3.1.min.js"></script> 
    <script src="/frontend/assets/js/tippy.all.min.js"></script>
    <script src="/frontend/assets/js/uikit.js"></script>
    <script src="/frontend/assets/js/simplebar.js"></script>
    <script src="/frontend/assets/js/custom.js"></script>
    <script src="/frontend/assets/js/bootstrap-select.min.js"></script>
    <script src="https://unpkg.com/ionicons@5.2.3/dist/ionicons.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    
</body>
</html><?php /**PATH /home/lap/workspace/alberto/nes/resources/views/public_profile.blade.php ENDPATH**/ ?>