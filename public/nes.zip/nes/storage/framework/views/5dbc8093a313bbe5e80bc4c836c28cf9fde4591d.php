

<?php if(env('USE_ABLY') == 'true'): ?>
<script src="//cdn.ably.io/lib/ably.min-1.js"></script>
<?php else: ?>
<script src="https://js.pusher.com/7.0/pusher.min.js"></script>
<?php endif; ?>

<script>
    var url = '/notification.mp3';  // notification sound

    <?php if($onMessageReceivedAlert == true): ?>
    // /messages, /messages/{id}
    // show the alert when a new notification arrives
    function emptyAlert() {
        $('.alert').hide();
        $('.alert').removeClass('alert-danger').removeClass('alert-primary');
        $('.alert .message').html('');
    }
    
    function showAlert(data, isMessageNotif) {
        var message = '';
        if (isMessageNotif) {
            $('.alert').addClass('alert-primary');
            message = '<a href="/public_profile/' + data['messagingUserID'] + ' class="alert-link">' + data['messagingUserName'] + '</a> te ha inviado un mensaje!';
        }
        else { // a like
            $('.alert').addClass('alert-danger');
            message = '<a href="/public_profile/' + data['likingUserID'] + ' class="alert-link">' + data['likingUserName'] + '</a> te ha inviado un mensaje!';
        }
        $('.alert .message').html(message);
        $('.alert').fadeIn();
        $('.alert').delay(5000).fadeOut('slow');  // hide alert after 5s
    }

    function onNotificationReceivedAlert(data, isMessageNotif) {
        emptyAlert();
        showAlert(data, isMessageNotif);
    }
    <?php endif; ?>

    <?php if($onMessageReceived == true): ?>
    // Notification of new message in the menu on the left
    // (i.e., list of all messages).
    function onMessageReceived(data)
    {
        console.log('onMessageReceived '); console.log(data)

        // put sender as first on the list on the right
        $('.messages-inbox-chat').each(function( index ) {
            if ($(this).data()['userId'] == data['messagingUserID']) {
                console.log('removing chat temporarily in left menu (list of chats)'); console.log($(this));
                $('.messages-inbox-chat')[index].remove();

                var newHTML = 
                '<li class="messages-inbox-chat" data-user-id="' + data['messagingUserID'] + '">' +
                    '<a href="/messages/' + data['messagingUserID'] + '">' +
                        '<div class="message-avatar"><i class="status-icon status-online"></i><img src="/profile_images/' + data['messagingUserImage'] + '" alt=""></div>' +

                        '<div class="message-by">' +
                            '<div class="message-by-headline">' +
                                '<h5>' + data['messagingUserName'] + '</h5>' +
                                '<span>Ahora</span>' +
                            '</div>' +
                            '<p style="font-weight: bold">' + data['message']['message'] + '</p>' +
                        '</div>' +
                    '</a>' +
                '</li>' + $('.messages-inbox-inner ul').html();

                $('.messages-inbox-inner ul').html(newHTML);
            }
        });

        // if chat is already open, add message and remove notification
        if ($('.active-message').data()['userId'] == data['messagingUserID']) {
            console.log('chat is already open, adding message to chat.');

            var newHtml = $('.message-content-inner').html() +
                '<div class="message-bubble">' +
                    '<div class="message-bubble-inner">' +
                        '<a href="/public_profile/' + data['messagingUserID'] + '"><div class="message-avatar"><img src="/profile_images/' + data['messagingUserImage'].trim() + '" alt=""></div></a>' +
                        '<div class="message-text"><p>' + data['message']['message'] + '</p></div>' +
                    '</div>' +
                    '<div class="clearfix"></div>' +
                '</div>';
            $('.message-content-inner').html(newHtml);

            // mark last message of this chat as read
            $('.active-message .message-by p').css('font-weight', 'normal');
        }
    }
    <?php endif; ?>

    <?php if(env('USE_ABLY') == 'true'): ?>
    var ably = new Ably.Realtime('bkgXjQ.E27aCQ:-n1JF3lVt_J1vaN7');
    <?php else: ?>
    // TODO Enable pusher logging - don't include this in production
    Pusher.logToConsole = true;

    var pusher = new Pusher('38fa39868a294edbbd46', {
        cluster: 'eu'
    });
    <?php endif; ?>

var channelT = ably.channels.get('TChannel');
channelT.publish('TestEvent', 'hello');

    <?php if(env('USE_ABLY') == 'true'): ?>
    var channelTest = ably.channels.get('TestChannel');
    channelTest.subscribe('TestEvent', function(data) {
    <?php else: ?>
    var channelTest = pusher.subscribe('TestChannel');
    channelTest.bind('TestEvent', function(data) {
    <?php endif; ?>
        alert(JSON.stringify(data));
    });

    <?php if(env('USE_ABLY') == 'true'): ?>
    var channelLike = ably.channels.get("LikeChannel-" + <?php echo e(auth()->user()->id); ?>);
    channelLike.subscribe('LikeEvent', function(data) {
    <?php else: ?>
    var channelLike = pusher.subscribe("LikeChannel-" + <?php echo e(auth()->user()->id); ?>);
    channelLike.bind('LikeEvent', function(data) {
    <?php endif; ?>
        console.log('pusher.blade.php: MessageEvent ' + JSON.stringify(data));
        
        var newHTML = 
        `<li>
            <a href="profile/public/${data["likingUserID"]}">
                <div class="drop_avatar"> 
                    <img src="/profile_images/${data["likingUserImage"]}" alt="user image">
                </div>
                <span class="drop_icon bg-gradient-primary">
                    <i class="icon-feather-thumbs-up"></i>
                </span>
                <div class="drop_text">
                    <p>
                    <strong>${data["likingUserName"]}</strong> te ha inviado un like!
                    <span class="text-link">Mira su perfil! </span>
                    </p>
                    <time> Ahora </time>
                </div>
            </a>
        </li>`;
        $("#notifications-ul").html(newHTML + $("#notifications-ul").html());
        var old_notification_number = $("#notification-number").html();
        if (old_notification_number == "")
            $("#notification-number").html(1);
        else 
            $("#notification-number").html(parseInt(old_notification_number) + 1);

        if (window.navigator && window.navigator.vibrate)
            window.navigator.vibrate(200);

        const audio = new Audio(url);
        audio.play();

        <?php if($onMessageReceivedAlert == true): ?>
        onNotificationReceivedAlert(data, false);
        <?php endif; ?>
    });

    <?php if(env('USE_ABLY') == 'true'): ?>
    var channelMessage = ably.channels.get("MessageChannel-" + <?php echo e(auth()->user()->id); ?>);
    channelMessage.subscribe('MessageEvent', function(data) {
    <?php else: ?>
    var channelMessage = pusher.subscribe("MessageChannel-" + <?php echo e(auth()->user()->id); ?>);
    channelMessage.bind('MessageEvent', function(data) {
    <?php endif; ?>
        console.log('pusher.blade.php: MessageEvent ' + JSON.stringify(data));
        
        // remove previous notification from the sending user
        $('#notification-messages-ul li').each(function( index ) {
            if (data["messagingUserID"] == $(this).data()['userId']) {
                var old_notification_number = $("#notificaton-messages-num").html();
                $("#notificaton-messages-num").html(parseInt(old_notification_number) - 1);
                $(this).remove();
            }
        });

        // if (window.location.href.indexOf("/messages") > -1 && 
        //     $('.active-message').data()['userId'] != data["messagingUserID"]) 
        // {
        // create a new notification (see .right-side in header.blade.php)
            var t = data['message']['created_at'].replace('T', ' ').split(/[- :]/);
            var created_at = new Date(Date.UTC(t[0], t[1]-1, t[2], t[3], t[4], t[5])).toLocaleDateString();
            data["messagingUserImage"] = data["messagingUserImage"].replace('\'%20+%20\'', '');
            var newHTML = 
                `<li class="un-read" data-user-id="${data["messagingUserID"]}">
                    <a href="/messages/${data['messagingUserID']}">
                        <div class="drop_avatar"> <img src="profile_images/' + ${data["messagingUserImage"]} + '" alt="">
                        </div>
                        <div class="drop_text">
                            <strong> ${data["messagingUserName"]} </strong> <time>${created_at}</time>
                            <p style="font-weight: bold">${data['message']["message"]}</p>
                        </div>
                    </a>
                </li>`;
            $('#notification-messages-ul').html($('#notification-messages-ul').html() + newHTML);

            var old_notification_number = $("#notificaton-messages-num").html();
            if (old_notification_number == "")
                $("#notificaton-messages-num").html(1);
            else 
                $("#notificaton-messages-num").html(parseInt(old_notification_number) + 1);
        // }

        if (window.navigator && window.navigator.vibrate)
            window.navigator.vibrate(200);

        const audio = new Audio(url);
        audio.play();

        <?php if($onMessageReceived == true): ?>
        // notify the other scripts that a message has been received
        onMessageReceived(data);
        <?php endif; ?>
        <?php if($onMessageReceivedAlert == true): ?>
        onNotificationReceivedAlert(data, true);
        <?php endif; ?>
    });
</script><?php /**PATH /home/lap/workspace/alberto/nes/resources/views/pusher.blade.php ENDPATH**/ ?>