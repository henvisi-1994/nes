<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Favicon -->
    <link href="/frontend/assets/images/favicon.png" rel="icon" type="image/png">

    <!-- Basic Page Needs
        ================================================== -->
    <title>Conocer</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Socialite is - Professional A unique and beautiful collection of UI elements">

    <!-- icons
    ================================================== -->
    <link rel="stylesheet" href="/frontend/assets/css/icons.css">

    <!-- CSS 
    ================================================== --> 
    <link rel="stylesheet" href="/frontend/assets/css/uikit.css">
    <link rel="stylesheet" href="/frontend/assets/css/style.css">
    <link rel="stylesheet" href="/frontend/assets/css/tailwind.css">  
    <link rel="stylesheet" href="/frontend/assets/css/custom.css">

    <!-- Font Awasome icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <?php echo $__env->make('pusher', array('onMessageReceived' => false, 'onMessageReceivedAlert' => false), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head> 
<body>
   

    <div id="wrapper">

        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Main Contents -->
        <div class="main_content">
            <div class="mcontainer">


                <div class="flex justify-between items-center relative md:mb-4 mb-3">
                    <div class="flex-1">
                        <h2 class="text-base font-semibold primary-color"> Otra manera de conocerse </h2>
                    </div>
                    <!-- <a href="#offcanvas-create" uk-toggle class="flex items-center justify-center z-10 h-10 w-10 rounded-full bg-blue-600 text-white absolute right-0"
                    data-tippy-placement="left" title="Create New Album">
                        <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clip-rule="evenodd"></path></svg>
                    </a> -->
                </div>

                
                <?php if(auth()->guard()->check()): ?>

                <div class="grid md:grid-cols-4 grid-cols-2 gap-3 mt-5">
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div>
                        <div class="bg-green-400 max-w-full lg:h-56 h-48 rounded-lg relative overflow-hidden shadow uk-transition-toggle">
                            <a href="/public_profile/<?php echo e($user->id); ?>">
                                <img src="profile_images/<?php echo e($user->image); ?>" class="w-full h-full absolute object-cover inset-0">
                            </a>
                            <!-- overly-->
                            <div class="-bottom-12 absolute bg-gradient-to-b from-transparent h-1/2 to-gray-800 uk-transition-slide-bottom-small w-full"></div>
                            <div class="absolute bottom-0 w-full p-3 text-white uk-transition-slide-bottom-small flex items-center">
                                <div class="flex-1"> 
                                    <div class="text-lg" style="font-weight: bold;"> <?php echo e($user->name); ?>, <?php echo e(date_diff(new \DateTime($user->birthday), new \DateTime())->format("%y")); ?>  </div>
                                    <div class="text-sm"> <?php if($user->city != ''): ?> <?php echo e($user->city); ?>, <?php endif; ?> <?php echo e($user->country); ?>  </div>
                                    <div class="flex space-x-3 lg:flex-initial text-sm">
                                        <?php if(in_array($user->id, $stars)): ?>
                                            <a href="#"><i class="fa fa-star colored" style="color:yellow" data-userid="<?php echo e($user->id); ?>" ></i></a>
                                        <?php else: ?>
                                            <a href="#"><i class="fa fa-star" data-userid="<?php echo e($user->id); ?>" ></i></a>
                                        <?php endif; ?>
                                        <a href="/messages/<?php echo e($user->id); ?>"><i class="fa fa-comment"></i></a>
                                        <?php if(in_array($user->id, $likes)): ?>
                                            <a href="#"><i class="fa fa-heart colored" style="color: red" data-userid="<?php echo e($user->id); ?>" ></i></a> 
                                        <?php else: ?>
                                            <a href="#"><i class="fa fa-heart" data-userid="<?php echo e($user->id); ?>" ></i></a> 
                                        <?php endif; ?>
                                    </div>
                                </div> 
                                
                            </div>
                        </div>
                    </div>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>Ningun usuario a&uacute;n</p>
                    <?php endif; ?>
                </div>

                <?php endif; ?>

        
            </div>
        </div>
        
    </div>

    <!-- Create new album -->
    


    <!-- open chat box -->
    
    
    

    
    <!-- For Night mode -->
    <script>
        (function (window, document, undefined) {
            'use strict';
            if (!('localStorage' in window)) return;
            var nightMode = localStorage.getItem('gmtNightMode');
            if (nightMode) {
                document.documentElement.className += ' night-mode';
            }
        })(window, document);
    
        (function (window, document, undefined) {
    
            'use strict';
    
            // Feature test
            if (!('localStorage' in window)) return;
    
            // Get our newly insert toggle
            var nightMode = document.querySelector('#night-mode');
            if (!nightMode) return;
    
            // When clicked, toggle night mode on or off
            nightMode.addEventListener('click', function (event) {
                event.preventDefault();
                document.documentElement.classList.toggle('dark');
                if (document.documentElement.classList.contains('dark')) {
                    localStorage.setItem('gmtNightMode', true);
                    return;
                }
                localStorage.removeItem('gmtNightMode');
            }, false);
    
        })(window, document);
    </script>
  
    <!-- Javascript
    ================================================== -->
    <script src="/frontend/assets/js/jquery-3.3.1.min.js"></script> 
    <script src="/frontend/assets/js/tippy.all.min.js"></script>
    <script src="/frontend/assets/js/uikit.js"></script>
    <script src="/frontend/assets/js/simplebar.js"></script>
    <script src="/frontend/assets/js/custom.js"></script>
    <script src="/frontend/assets/js/bootstrap-select.min.js"></script>
    <script src="https://unpkg.com/ionicons@5.2.3/dist/ionicons.js"></script>

    <script>
        $(document.body).on('click', '.fa-star', function () {
            var userid = $(this).data()['userid'];
            var _this = $(this);
            if ($(this).css("color") == "rgb(255, 255, 255)") {
                $.get( "/star/" + userid, function( data ) {
                    _this.css({ color: "yellow" });
                })
            }
            else {
                $.get( "/unstar/" + userid, function( data ) {
                    _this.css({ color: "rgb(255, 255, 255)" });
                })
            }
        });

        $(document.body).on('click', '.fa-heart', function () {
            var userid = $(this).data()['userid'];
            var _this = $(this);
            if ($(this).css("color") == "rgb(255, 255, 255)") {
                $.get( "/like/" + userid, function( data ) {
                    console.log(data)
                    _this.css({ color: "red" });
                })
            }
            else {
                $.get( "/unlike/" + userid, function( data ) {
                    console.log(data)
                    _this.css({ color: "rgb(255, 255, 255)" });
                })
            }
        });

        $(document).ready(function() {
            $(".fa-star:not(.colored)").css({ color: "rgb(255, 255, 255)" });
            $(".fa-heart:not(.colored)").css({ color: "rgb(255, 255, 255)" });
            $(".fa-comment").css({ color: "rgb(255, 255, 255)" });
        });
    </script>

    <?php echo $__env->make('notifications_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH /home/lap/workspace/alberto/nes/resources/views/conocer.blade.php ENDPATH**/ ?>